Movement:
A D for turning

Ocatahederal infinite tunnel

Shader Tasks:
Grayscale toggle with 'G'
Textured walls



Bonus:
Friction
Score on screen
Speeds up based on score