var main=function() {
	var timeElement = document.getElementById("score");
	var timeNode = document.createTextNode("");
	timeElement.appendChild(timeNode);

	var lvlElement = document.getElementById("lvl");
	var lvlNode = document.createTextNode("");
	lvlElement.appendChild(lvlNode);

  var CANVAS=document.getElementById("your_canvas");
  CANVAS.width=window.innerWidth;
  CANVAS.height=window.innerHeight;

  /*========================= GET WEBGL CONTEXT ========================= */
  var GL;
  try {
    GL = CANVAS.getContext("experimental-webgl", {antialias: true});
  } catch (e) {
    alert("You are not webgl compatible :(") ;
    return false;
  }

  /*========================= SHADERS ========================= */
  /*jshint multistr: true */

  var shader_vertex_source="\n\
attribute vec3 position;\n\
uniform mat4 Pmatrix;\n\
uniform mat4 Vmatrix;\n\
uniform mat4 Mmatrix;\n\
attribute vec2 uv;\n\
varying vec2 vUV;\n\
void main(void) { //pre-built function\n\
gl_Position = Pmatrix*Vmatrix*Mmatrix*vec4(position, 1.);\n\
vUV=uv;\n\
}";

  var shader_fragment_source="\n\
precision mediump float;\n\
uniform float greyscality;\n\
uniform sampler2D sampler;\n\
varying vec2 vUV;\n\
vec4 vColor;\n\
\n\
\n\
void main(void) {\n\
vColor = texture2D(sampler, vUV);\n\
float greyscaleValue=(vColor.r+vColor.g+vColor.b)/3.;\n\
vec3 greyscaleColor=vec3(greyscaleValue,greyscaleValue,greyscaleValue);\n\
if(greyscality == 1.) gl_FragColor = vColor;\n\
if(greyscality == 0.) gl_FragColor = vec4(greyscaleColor, 1.);\n\
}";

  var get_shader=function(source, type, typeString) {
    var shader = GL.createShader(type);
    GL.shaderSource(shader, source);
    GL.compileShader(shader);
    if (!GL.getShaderParameter(shader, GL.COMPILE_STATUS)) {
      alert("ERROR IN "+typeString+ " SHADER : " + GL.getShaderInfoLog(shader));
      return false;
    }
    return shader;
  };

  var shader_vertex=get_shader(shader_vertex_source, GL.VERTEX_SHADER, "VERTEX");
  var shader_fragment=get_shader(shader_fragment_source, GL.FRAGMENT_SHADER, "FRAGMENT");
  //console.log(shader_fragment);

  var SHADER_PROGRAM=GL.createProgram();
  GL.attachShader(SHADER_PROGRAM, shader_vertex);
  GL.attachShader(SHADER_PROGRAM, shader_fragment);

  GL.linkProgram(SHADER_PROGRAM);

  var _Pmatrix = GL.getUniformLocation(SHADER_PROGRAM, "Pmatrix");
  var _Vmatrix = GL.getUniformLocation(SHADER_PROGRAM, "Vmatrix");
  var _Mmatrix = GL.getUniformLocation(SHADER_PROGRAM, "Mmatrix");
  var _greyscality=GL.getUniformLocation(SHADER_PROGRAM, "greyscality");

  var _sampler = GL.getUniformLocation(SHADER_PROGRAM, "sampler");
  var _uv = GL.getAttribLocation(SHADER_PROGRAM, "uv");
  var _position = GL.getAttribLocation(SHADER_PROGRAM, "position");

  GL.enableVertexAttribArray(_uv);
  GL.enableVertexAttribArray(_position);

  GL.useProgram(SHADER_PROGRAM);
  GL.uniform1i(_sampler, 0);


  /*========================= THE TRIANGLE ========================= */
  //POINTS :
  var triangle_vertex=[
    -1,-1,0,
    0,0,1,
    1,-1,0,
    1,1,0,
    1,1,0,
    1,0,0
  ];

  var TRIANGLE_VERTEX= GL.createBuffer ();
  GL.bindBuffer(GL.ARRAY_BUFFER, TRIANGLE_VERTEX);
  GL.bufferData(GL.ARRAY_BUFFER,
                new Float32Array(triangle_vertex),
    GL.STATIC_DRAW);

  //FACES :
  var triangle_faces = [0,1,2];
  var TRIANGLE_FACES= GL.createBuffer ();
  GL.bindBuffer(GL.ELEMENT_ARRAY_BUFFER, TRIANGLE_FACES);
  GL.bufferData(GL.ELEMENT_ARRAY_BUFFER,
                new Uint16Array(triangle_faces),
    GL.STATIC_DRAW);


  /*========================= THE TUNNEL ========================= */
  	tunnel1 = new Tunnel(0);
 	TUNNEL_VERTEX= GL.createBuffer ();
    GL.bindBuffer(GL.ARRAY_BUFFER, TUNNEL_VERTEX);
    GL.bufferData(GL.ARRAY_BUFFER, new Float32Array(tunnel1.vertex), GL.STATIC_DRAW);

    var TUNNEL_FACES= GL.createBuffer ();
  	GL.bindBuffer(GL.ELEMENT_ARRAY_BUFFER, TUNNEL_FACES);
  	GL.bufferData(GL.ELEMENT_ARRAY_BUFFER, new Uint16Array(tunnel1.faces), GL.STATIC_DRAW);



  /*========================= MATRIX ========================= */

  var PROJMATRIX=LIBS.get_projection(40, CANVAS.width/CANVAS.height, 0, 1000);
  var VIEWMATRIX=LIBS.get_I4();
  
  var TUNNEL1_MOVEMATRIX=LIBS.get_I4();
  var TUNNEL2_MOVEMATRIX=LIBS.get_I4();
  var OBS_MOVEMATRIX=LIBS.get_I4();



  LIBS.translate(VIEWMATRIX, 0, 0.5, 0.1);
  LIBS.translate(TUNNEL2_MOVEMATRIX, 0, 0, tunnel1.length);


  /*========================= TEXTURES ========================= */
  var get_texture=function(image_URL){


    var image=new Image();

    image.src=image_URL;
    image.webglTexture=false;


    image.onload=function(e) {



      var texture=GL.createTexture();

      GL.pixelStorei(GL.UNPACK_FLIP_Y_WEBGL, true);


      GL.bindTexture(GL.TEXTURE_2D, texture);

      GL.texImage2D(GL.TEXTURE_2D, 0, GL.RGBA, GL.RGBA, GL.UNSIGNED_BYTE, image);

      GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_MAG_FILTER, GL.LINEAR);

      GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_MIN_FILTER, GL.NEAREST_MIPMAP_LINEAR);

      GL.generateMipmap(GL.TEXTURE_2D);

      GL.bindTexture(GL.TEXTURE_2D, null);

      image.webglTexture=texture;
    };

    return image;
  };

  var cube_texture=get_texture("Resources/final.jpg");


  /* ========================= DRAWING ========================= */
  GL.clearColor(0.0, 0.0, 0.0, 0.0);

  GL.enable(GL.DEPTH_TEST);
  GL.depthFunc(GL.LEQUAL);

  GL.clearDepth(1.0);
  var time_old=0;


  var w = 0, theta = 0;
  var tunnel_count = 0;
  var gray = 1;
  var score = 0, level = 1;
  var animate=function(time) {
    var dt=time-time_old;

    //Forward motion
    if (score < 100) {LIBS.translate(VIEWMATRIX, 0, 0, 0.25);}
    if (score >= 100) {LIBS.translate(VIEWMATRIX, 0, 0, 0.27); level = 2;}
    if (score > 200) {LIBS.translate(VIEWMATRIX, 0, 0, 0.29); level = 3;}
    if (score > 400) {LIBS.translate(VIEWMATRIX, 0, 0, 0.31); level = 4;}
    if (score > 700) {LIBS.translate(VIEWMATRIX, 0, 0, 0.33); level = 5;}
    if (score > 1100) {LIBS.translate(VIEWMATRIX, 0, 0, 0.35); level = 6;}
    z_camera = VIEWMATRIX[14];

    //Infinite tunnel
    ratio = Math.floor(z_camera/-tunnel1.length);
    if (ratio > tunnel_count){
    	tunnel_count++;
    	if(tunnel_count%2 == 0) LIBS.translate(TUNNEL2_MOVEMATRIX, 0, 0, 2*tunnel1.length);
    	else LIBS.translate(TUNNEL1_MOVEMATRIX, 0, 0, 2*tunnel1.length);
    }

    //Score
    score = Math.floor(z_camera);
    document.title = 'Score: ' + score.toString();	
    timeNode.nodeValue = score.toString();
    lvlNode.nodeValue = level.toString();
    
    //Side motion
    Mousetrap.bind('a', function() { 
    	w += 0.07;
	});
	Mousetrap.bind('d', function() { 
    	w -= 0.07;
	});

	//Angular velocity logic
	w -= 0.08*w;	//Friction
	LIBS.rotateZ(VIEWMATRIX, w);
	theta += w;
	if (theta < 0) theta+=2*Math.PI;
	theta = theta%(2*Math.PI);


	//Grayscale
	Mousetrap.bind('g', function() { 
    	if(gray == 1) gray = 0;
    	else gray = 1;
	});

    time_old=time;

    GL.viewport(0.0, 0.0, CANVAS.width, CANVAS.height);
    GL.clear(GL.COLOR_BUFFER_BIT | GL.DEPTH_BUFFER_BIT);
    GL.uniformMatrix4fv(_Pmatrix, false, PROJMATRIX);
    GL.uniformMatrix4fv(_Vmatrix, false, VIEWMATRIX);

    //Tunnel1
    GL.uniformMatrix4fv(_Mmatrix, false, TUNNEL1_MOVEMATRIX);
    if (cube_texture.webglTexture) {

      GL.activeTexture(GL.TEXTURE0);

      GL.bindTexture(GL.TEXTURE_2D, cube_texture.webglTexture);
    }
    GL.uniform1f(_greyscality, gray);
    GL.bindBuffer(GL.ARRAY_BUFFER, TUNNEL_VERTEX);
    GL.vertexAttribPointer(_position, 3, GL.FLOAT, false,4*(3+2),0) ;
    GL.vertexAttribPointer(_uv, 2, GL.FLOAT, false,4*(3+2),3*4) ;
  	GL.bindBuffer(GL.ELEMENT_ARRAY_BUFFER, TUNNEL_FACES);
    GL.drawElements(GL.TRIANGLES, 16*3, GL.UNSIGNED_SHORT, 0); //No of triangles * 3
    
    //Tunnel2
    GL.uniformMatrix4fv(_Mmatrix, false, TUNNEL2_MOVEMATRIX);
    GL.drawElements(GL.TRIANGLES, 16*3, GL.UNSIGNED_SHORT, 0); 


    GL.flush();

    window.requestAnimationFrame(animate);
  };


  animate(0);
};