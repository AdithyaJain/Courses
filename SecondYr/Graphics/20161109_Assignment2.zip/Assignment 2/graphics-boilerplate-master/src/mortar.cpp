#include "mortar.h"
#include "main.h"

void Mortar::insert_cube(GLfloat *vertex_buffer_data_pointer, int vertex_buffer_index, GLfloat *cube, float x, float y, float z)
{
    for(int i=0; i<108; i++)
    {
        if(i%3 == 0) vertex_buffer_data_pointer[vertex_buffer_index + i] = x+cube[i]; //x
        if(i%3 == 1) vertex_buffer_data_pointer[vertex_buffer_index + i] = y+cube[i]; //y
        if(i%3 == 2) vertex_buffer_data_pointer[vertex_buffer_index + i] = z+cube[i]; //z
    }
}

Mortar::Mortar(float x, float y, float z, color_t color1, color_t color2, color_t color3) {
    this->position = glm::vec3(x, y, z);
    this->rotation = 0; // Angle with -z axis
    GLfloat cube[] = {
        -1.0f,-1.0f,-1.0f, // triangle 1 : begin
        -1.0f,-1.0f, 1.0f,
        -1.0f, 1.0f, 1.0f, // triangle 1 : end
        1.0f, 1.0f,-1.0f, // triangle 2 : begin
        -1.0f,-1.0f,-1.0f,
        -1.0f, 1.0f,-1.0f, // triangle 2 : end
        1.0f,-1.0f, 1.0f,
        -1.0f,-1.0f,-1.0f,
        1.0f,-1.0f,-1.0f,
        1.0f, 1.0f,-1.0f,
        1.0f,-1.0f,-1.0f,
        -1.0f,-1.0f,-1.0f,
        -1.0f,-1.0f,-1.0f,
        -1.0f, 1.0f, 1.0f,
        -1.0f, 1.0f,-1.0f,
        1.0f,-1.0f, 1.0f,
        -1.0f,-1.0f, 1.0f,
        -1.0f,-1.0f,-1.0f,
        -1.0f, 1.0f, 1.0f,
        -1.0f,-1.0f, 1.0f,
        1.0f,-1.0f, 1.0f,
        1.0f, 1.0f, 1.0f,
        1.0f,-1.0f,-1.0f,
        1.0f, 1.0f,-1.0f,
        1.0f,-1.0f,-1.0f,
        1.0f, 1.0f, 1.0f,
        1.0f,-1.0f, 1.0f,
        1.0f, 1.0f, 1.0f,
        1.0f, 1.0f,-1.0f,
        -1.0f, 1.0f,-1.0f,
        1.0f, 1.0f, 1.0f,
        -1.0f, 1.0f,-1.0f,
        -1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f,
        -1.0f, 1.0f, 1.0f,
        1.0f,-1.0f, 1.0f
    };
    GLfloat vertex_buffer_data[8*108];
    insert_cube(vertex_buffer_data, 108*0, cube, -2, 0, 2);//first
    insert_cube(vertex_buffer_data, 108*1, cube, -2, 0, 0);
    insert_cube(vertex_buffer_data, 108*2, cube, -2, 0, -2);
    insert_cube(vertex_buffer_data, 108*3, cube, 2, 0, 2);//second
    insert_cube(vertex_buffer_data, 108*4, cube, 2, 0, 0);
    insert_cube(vertex_buffer_data, 108*5, cube, 2, 0, -2);
    insert_cube(vertex_buffer_data, 108*6, cube, 0, 0, 2);//middle
    insert_cube(vertex_buffer_data, 108*7, cube, 0, 0, -2);

    this->object1 = create3DObject(GL_TRIANGLES, 12*3*3, vertex_buffer_data, color1, GL_FILL);
    this->object2 = create3DObject(GL_TRIANGLES, 12*3*3, &vertex_buffer_data[324], color2, GL_FILL);
    this->object3 = create3DObject(GL_TRIANGLES, 12*3*2, &vertex_buffer_data[648], color3, GL_FILL);
}

void Mortar::draw(glm::mat4 VP) {
    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    glm::mat4 rotate    = glm::rotate((float) (this->rotation * M_PI / 180.0f), glm::vec3(0, 1, 0));
    // No need as coords centered at 0, 0, 0 of cube arouund which we waant to rotate
    // rotate          = rotate * glm::translate(glm::vec3(0, -0.6, 0));
    Matrices.model *= (translate * rotate);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->object1);
    draw3DObject(this->object2);
    draw3DObject(this->object3);
}

void Mortar::set_position(float x, float y) {
    this->position = glm::vec3(x, y, 0);
}

void Mortar::tick() {
}

bounding_box_t Mortar::bounding_box() {
    float x = this->position.x, z = this->position.z;
    bounding_box_t bbox = { x, z, 6, 6 };
    return bbox;
}
bounding_box_t Mortar::agro_box() {
    float x = this->position.x, z = this->position.z;
    bounding_box_t bbox = { x, z, 75, 75 };
    return bbox;
}

