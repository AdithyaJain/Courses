#include "main.h"

#ifndef MORTAR_H
#define MORTAR_H


class Mortar {
public:
    Mortar() {}
    Mortar(float x, float y, float z, color_t color1, color_t color2, color_t color3);
    glm::vec3 position;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y);
    void tick();
    bounding_box_t bounding_box(), agro_box();
    void insert_cube(GLfloat *vertex_buffer_data_pointer, int vertex_buffer_index, GLfloat *cube, float x, float y, float z);
private:
    VAO *object1, *object2, *object3;
};

#endif // MORTAR_H
