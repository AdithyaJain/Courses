#include "main.h"
#include "timer.h"
#include "ball.h"
#include "rock.h"
#include "water.h"
#include "cannon.h"
#include "enemy.h"
#include "barrel.h"
#include "healthpickup.h"
#include "mortar.h"
#include "boss.h"

#define ROCK_COUNT 4

using namespace std;

GLMatrices Matrices;
GLuint     programID;
GLFWwindow *window;

Water water;
Ball player;
Rock rock[ROCK_COUNT];
Barrel barrel[4];
HealthPickUp healthpickup[5];
Cannon cannon, mortar_cannon, boss_cannon;
Enemy enemy;
Mortar mortar;
Boss boss;
bool is_fire = false, mortar_fire = false, boss_fire = false;
//Screen center and size
float screen_zoom = 1, screen_center_x = 0, screen_center_y = 0;
// sin(y) gives y
// cos(y)cos(xz) gives x
// cos(y)sin(xz) gives z
float camera_xz_angle = 80, camera_y_angle = 30;
//Ortho or perspective
char project_char = 'p';
// DIFFERENT CAMERA VIEWS
enum camera{BOAT_V, TOP_V, TOWER_V, FOLLOW_V, HELICOPTER_V};
enum camera cam_view = HELICOPTER_V;
// HP related
int invincibility_count = 0, mortar_invincibility = 0, boss_invincibility = 0;
int player_hp_current = 3, player_hp_old =  3;
int mortar_hp_current = 3, mortar_hp_old = 3, enemy_hp = 1;
int boss_hp_current = 9, boss_hp_old = 9;
//WIND
glm::vec3 wind_dir(0, 0, 0);
//Speed up
float speed_ratio = 1;

//Cutscene
int cutscene_count = 0, duration = 105*6;
bool is_boss = false, reverse_cutscene = false;

//Mouse
double old_x, old_y, current_x, current_y;


Timer t60(1.0 / 60);

void draw() {
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glUseProgram (programID);


    glm::vec3 eye = glm::vec3 ( 60*cos(camera_xz_angle*M_PI/180.0f)*cos(camera_y_angle*M_PI/180.0f), 60*sin(camera_y_angle*M_PI/180.0f), 60*sin(camera_xz_angle*M_PI/180.0f)*cos(camera_y_angle*M_PI/180.0f) );
    glm::vec3 target = glm::vec3(0,0,0);
    glm::vec3 up = glm::vec3(0, 1, 0);
    if (cam_view == BOAT_V && cutscene_count == 0){
        eye = player.position + 5.0f*player.direction + glm::vec3(0,1,0); // CHANGE IF BOAT SPRITE CHANGES
        target = eye + player.direction;
        up = glm::vec3(0,1,0);
    }
    else if (cam_view == TOP_V){
        if (cutscene_count == 0){
            eye = player.position + glm::vec3(-10, 171, -10);
            target = player.position;
            up = glm::vec3(0,0,-1);
        }
        else if (cutscene_count >= duration - 390){
            eye = glm::vec3(-10, 171, -10);
            target = glm::vec3(0, 0, 0);
            up = glm::vec3(0,0,-1);
        }
        else if (cutscene_count <= 240 && cutscene_count >=120){
            eye = glm::vec3(-10, 171, ((5*cutscene_count)/6)-200 -10);
            target = glm::vec3(0, 0, ((5*cutscene_count)/6)-200);
            up = glm::vec3(0,0,-1);
        }
        else{
            eye = glm::vec3(-10, 171, -100-10);
            target = glm::vec3(0, 0, -100);
            up = glm::vec3(0,0,-1);
        }
    }
    else if (cam_view == TOWER_V && cutscene_count == 0){
        eye = glm::vec3(0, 100, 200);
        target = glm::vec3(0,0,0);
        up = glm::vec3(0,1,0);
    }
    else if (cam_view == FOLLOW_V && cutscene_count == 0){
        eye = player.position - 60.0f*player.direction + glm::vec3(0, 30, 0);
        target = player.position;
        up = glm::vec3(0,1,0);
    }
    else if (cam_view == HELICOPTER_V && cutscene_count == 0){
        glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
        eye = player.position + glm::vec3 ( 70*cos(camera_xz_angle*M_PI/180.0f)*cos(camera_y_angle*M_PI/180.0f), 70*sin(camera_y_angle*M_PI/180.0f), 70*sin(camera_xz_angle*M_PI/180.0f)*cos(camera_y_angle*M_PI/180.0f) );
        target = player.position;
        up = glm::vec3(0, 1, 0);
    }

    // Compute Camera matrix (view)
    Matrices.view = glm::lookAt( eye, target, up ); // Rotating Camera for 3D
    glm::mat4 VP = Matrices.projection * Matrices.view;
    glm::mat4 MVP;  // MVP = Projection * View * Model

    // Scene render
    water.draw(VP);
    if((invincibility_count/10)%2 == 0)player.draw(VP);
    for(int i=0; i<ROCK_COUNT; i++) rock[i].draw(VP);
    for(int i=0; i<4; i++) barrel[i].draw(VP);
    for(int i=0; i<5; i++) healthpickup[i].draw(VP);
    if(is_fire) cannon.draw(VP);
    if(mortar_fire) mortar_cannon.draw(VP);
    if(boss_fire) boss_cannon.draw(VP);
    enemy.draw(VP);
    mortar.draw(VP);
    /*if(is_boss) */boss.draw(VP);
}

void tick_input(GLFWwindow *window) {
//PROJECTION
    int ortho_key = glfwGetKey(window, GLFW_KEY_O);
    int persp_key = glfwGetKey(window, GLFW_KEY_P);
    if (ortho_key) {project_char = 'o'; reset_screen();}
    else if (persp_key) {project_char = 'p'; reset_screen();}
//CAMERA VIEW
    int boat = glfwGetKey(window, GLFW_KEY_1);
    int top = glfwGetKey(window, GLFW_KEY_2);
    int tower = glfwGetKey(window, GLFW_KEY_3);
    int follow = glfwGetKey(window, GLFW_KEY_4);
    int heli = glfwGetKey(window, GLFW_KEY_5);
    if (boat && cutscene_count == 0) cam_view = BOAT_V;
    else if(top) cam_view = TOP_V;
    else if(tower && cutscene_count == 0) cam_view = TOWER_V;
    else if(follow && cutscene_count == 0) cam_view = FOLLOW_V;
    else if(heli && cutscene_count == 0) cam_view = HELICOPTER_V;

//PLAYER
    int player_front = glfwGetKey(window, GLFW_KEY_W);
    int player_back = glfwGetKey(window, GLFW_KEY_S);
    int player_left = glfwGetKey(window, GLFW_KEY_A);
    int player_right = glfwGetKey(window, GLFW_KEY_D);
    int player_jump = glfwGetKey(window, GLFW_KEY_SPACE);
    if(player_front && cutscene_count == 0){
            player.acc.x = speed_ratio*0.05f*player.direction.x + wind_dir.x;
            player.acc.z = speed_ratio*0.05f*player.direction.z + wind_dir.z;
    }
    else if(player_back && cutscene_count == 0){
        player.acc.x = -speed_ratio*0.05f*player.direction.x + wind_dir.x;
        player.acc.z = -speed_ratio*0.05f*player.direction.z + wind_dir.z;
    }
    else{ player.acc.x = wind_dir.x; player.acc.z = wind_dir.z;}
    if(player_left){
        player.rotation += speed_ratio*1;
    }
    if(player_right){
        player.rotation -= speed_ratio*1;
    }
    if(player_jump && player.position.y == 0){
        player.speed.y = 1;
    }
//Cannon
    int fire_cannon = glfwGetKey(window, GLFW_KEY_F);
    if(fire_cannon && !is_fire){
        cannon = Cannon(player.position.x, player.position.y+1, player.position.z, player.direction.x + player.speed.x, 0.25 , player.direction.z + player.speed.z , COLOR_BLACK);
        is_fire = true;
    }
    if(cannon.position.y < -2) is_fire = false;

//Collision with rock
    for(int i=0; i<ROCK_COUNT; i++){
        if (detect_collision(player.bounding_box(), rock[i].bounding_box()) && invincibility_count<=0 && player.position.y < 2){
            player_hp_old = player_hp_current;
            player_hp_current--;
            invincibility_count = 90;//1 sec
            player.speed.x -= 0.5f*abs(player.speed.x)*(rock[i].position.x - player.position.x);
            player.speed.z -= 0.5f*abs(player.speed.z)*(rock[i].position.z - player.position.z);
        }
    }
//Collision with barrel
    for(int i=0; i<4; i++){
        if (detect_collision(player.bounding_box(), barrel[i].bounding_box()) && player.position.y < 2){
            player.speed.x -= 0.5f*abs(player.speed.x)*(barrel[i].position.x - player.position.x);
            player.speed.z -= 0.5f*abs(player.speed.z)*(barrel[i].position.z - player.position.z);
        }
    }

//Collision with enemy
    if (detect_collision(player.bounding_box(), enemy.bounding_box()) && invincibility_count<=0 && player.position.y < 2){
        player_hp_old = player_hp_current;
        player_hp_current--;
        invincibility_count = 90;//1.5 sec
        player.speed.x -= 0.5f*abs(player.speed.x)*(enemy.position.x - player.position.x);
        player.speed.z -= 0.5f*abs(player.speed.z)*(enemy.position.z - player.position.z);
    }
//Collision with mortar
    if (detect_collision(player.bounding_box(), mortar.bounding_box()) && invincibility_count<=0 && player.position.y < 2){
        player_hp_old = player_hp_current;
        player_hp_current--;
        invincibility_count = 90;//1.5 sec
        player.speed.x -= 0.2f*abs(player.speed.x)*(mortar.position.x - player.position.x);
        player.speed.z -= 0.2f*abs(player.speed.z)*(mortar.position.z - player.position.z);
    }
//Collision with mortar cannon
    if (mortar_fire && detect_collision(player.bounding_box(), mortar_cannon.bounding_box()) && abs(player.position.y - mortar_cannon.position.y) < 1.5 && invincibility_count <= 0){
        player_hp_old = player_hp_current;
        player_hp_current--;
        invincibility_count = 90;//1.5 sec
    }

//Collision with boss
    if (detect_collision(player.bounding_box(), boss.bounding_box()) && invincibility_count<=0){
        player_hp_old = player_hp_current;
        player_hp_current--;
        invincibility_count = 90;//1.5 sec
        player.speed.x -= 0.5f*(boss.position.x - player.position.x);
        player.speed.z -= 0.5f*(boss.position.z - player.position.z);
    }

//Collision with boss cannon
    if (boss_fire && detect_collision(player.bounding_box(), boss_cannon.bounding_box()) && abs(player.position.y - boss_cannon.position.y) < 1.5 && invincibility_count <= 0){
        player_hp_old = player_hp_current;
        player_hp_current--;
        invincibility_count = 90;//1.5 sec
    }

//AGRO
//Collision with mortar agro range
    if (detect_collision(player.bounding_box(), mortar.agro_box()) && !mortar_fire){
        mortar_cannon = Cannon(mortar.position.x, mortar.position.y+1, mortar.position.z, 0.025f*(player.position.x - mortar.position.x), 1, 0.025f*(player.position.z - mortar.position.z), COLOR_BLACK);
        mortar_cannon.acc.y = -0.05;
        mortar_fire = true;
    }
    if(mortar_cannon.position.y < -2) mortar_fire = false;

//Collision with enemy agro range
    if (detect_collision(player.bounding_box(), enemy.agro_box())){
        enemy.xspeed = 0.02f*(player.position.x - enemy.position.x);
        enemy.zspeed = 0.02f*(player.position.z - enemy.position.z);
    }
    else{
        enemy.xspeed = enemy.zspeed = 0;
    }
//Collision with boss agro range
    if (detect_collision(player.bounding_box(), boss.agro_box())){
        if(!boss_fire){
            boss_cannon = Cannon(boss.position.x, boss.position.y + 2, boss.position.z, 0.025f*(player.position.x - boss.position.x), 1, 0.025f*(player.position.z - boss.position.z), COLOR_BLACK);
            boss_cannon.acc.y = -0.05;
            boss_fire = true;
        }
        boss.speed.x = 0.01f*(player.position.x - boss.position.x);
        boss.speed.z = 0.01f*(player.position.z - boss.position.z);
    }
    if(boss_cannon.position.y < -2) boss_fire = false;



//YOU DAMAGING ENEMIES
//Collision of enemy with cannon
    if (detect_collision(cannon.bounding_box(), enemy.bounding_box())  && abs(cannon.position.y-enemy.position.y) < 3){
        healthpickup[4]= HealthPickUp(enemy.position.x, 4, enemy.position.z, COLOR_BOAT);
        enemy.position = glm::vec3(1000,0,0);
        enemy_hp = 0;
    }
//Collision of mortar with cannon
    if(detect_collision(cannon.bounding_box(), mortar.bounding_box()) && abs(cannon.position.y-mortar.position.y) < 3 && mortar_invincibility <= 0){
        mortar_hp_old = mortar_hp_current;
        mortar_hp_current--;
        mortar_invincibility = 30;
    }
//Collision of boss with cannon
    if(detect_collision(cannon.bounding_box(), boss.bounding_box()) && boss_invincibility <= 0){
        boss_hp_old = boss_hp_current;
        boss_hp_current--;
        boss_invincibility = 30;
    }

//Collision Jump over barrels
    for(int i=0; i<4; i++){
        if (detect_collision(player.bounding_box(), healthpickup[i].bounding_box())){
            healthpickup[i].position = glm::vec3(1000,4,0);
            if(player_hp_current < 3){
                player_hp_old = player_hp_current;
                player_hp_current++;
            }
        }
    }
    if (detect_collision(player.bounding_box(), healthpickup[4].bounding_box())){
        healthpickup[4].position = glm::vec3(1000,4,0);
        if(player_hp_current < 3){
            player_hp_old = player_hp_current;
            player_hp_current++;
        }
    }

//Invincibility after hit
    if(invincibility_count > 0) invincibility_count--;
    if(mortar_invincibility > 0) mortar_invincibility--;
    if(boss_invincibility > 0) boss_invincibility--;

//PLAYER HP
    if (player_hp_current != player_hp_old){ //ie. player health has changed:
        if(player_hp_current >=3) player = Ball(player.position.x, player.position.y, player.position.z, player.rotation, player.direction, player.speed, COLOR_BOAT, COLOR_BOAT, COLOR_BOAT, COLOR_SAIL);
        else if(player_hp_current ==2) player = Ball(player.position.x, player.position.y, player.position.z, player.rotation, player.direction, player.speed, COLOR_DMG_BOAT, COLOR_BOAT, COLOR_BOAT, COLOR_SAIL);
        else if(player_hp_current ==1) player = Ball(player.position.x, player.position.y, player.position.z, player.rotation, player.direction, player.speed, COLOR_DMG_BOAT, COLOR_DMG_BOAT, COLOR_BOAT, COLOR_SAIL);
        player_hp_old = player_hp_current;
    }
    if (player_hp_current == 0) quit(window);
//Mortar HP
    if (mortar_hp_current != mortar_hp_old){ //ie. mortar health has changed:
        if(mortar_hp_current >=3) mortar = Mortar(-50*1.4, 0, -50*1.4, COLOR_GREY,COLOR_GREY,COLOR_GREY);
        else if(mortar_hp_current ==2) mortar = Mortar(-50*1.4, 0, -50*1.4, COLOR_BLACK,COLOR_GREY,COLOR_GREY);
        else if(mortar_hp_current ==1) mortar = Mortar(-50*1.4, 0, -50*1.4, COLOR_BLACK,COLOR_BLACK,COLOR_GREY);
        mortar_hp_old = mortar_hp_current;
    }
    if (mortar_hp_current == 0) mortar = Mortar(1010, 0, 0, COLOR_GREY,COLOR_GREY,COLOR_GREY);

//Boss Hp
    if (boss_hp_current != boss_hp_old){
        if (boss_hp_current == 8) boss = Boss(boss.position.x, boss.position.y, boss.position.z, boss.rotation, boss.direction, boss.speed, COLOR_GREY3, COLOR_BLACK, COLOR_BLACK, COLOR_RED);
        else if(boss_hp_current == 7) boss = Boss(boss.position.x, boss.position.y, boss.position.z, boss.rotation, boss.direction, boss.speed, COLOR_GREY2, COLOR_BLACK, COLOR_BLACK, COLOR_RED);
        else if(boss_hp_current == 6) boss = Boss(boss.position.x, boss.position.y, boss.position.z, boss.rotation, boss.direction, boss.speed, COLOR_GREY, COLOR_BLACK, COLOR_BLACK, COLOR_RED);
        else if(boss_hp_current == 5) boss = Boss(boss.position.x, boss.position.y, boss.position.z, boss.rotation, boss.direction, boss.speed, COLOR_GREY, COLOR_GREY3, COLOR_BLACK, COLOR_RED);
        else if(boss_hp_current == 4) boss = Boss(boss.position.x, boss.position.y, boss.position.z, boss.rotation, boss.direction, boss.speed, COLOR_GREY, COLOR_GREY2, COLOR_BLACK, COLOR_RED);
        else if(boss_hp_current == 3) boss = Boss(boss.position.x, boss.position.y, boss.position.z, boss.rotation, boss.direction, boss.speed, COLOR_GREY, COLOR_GREY, COLOR_BLACK, COLOR_RED);
        else if(boss_hp_current == 2) boss = Boss(boss.position.x, boss.position.y, boss.position.z, boss.rotation, boss.direction, boss.speed, COLOR_GREY, COLOR_GREY, COLOR_GREY3, COLOR_RED);
        else if(boss_hp_current == 1) boss = Boss(boss.position.x, boss.position.y, boss.position.z, boss.rotation, boss.direction, boss.speed, COLOR_GREY, COLOR_GREY, COLOR_GREY2, COLOR_RED);
        boss_hp_old = boss_hp_current;
    }
    if(boss_hp_current == 0){ boss.position.x = 1000; speed_ratio = 2;}

//Cutscene
    if (enemy_hp == 0 && mortar_hp_current == 0){
        cutscene_count = duration; //8.5 secs
        enemy_hp--;
        mortar_hp_current--;
        cam_view = TOP_V;
        player.position.x = 0;
        player.position.z = 0;
        player.speed = glm::vec3(0,0,0);
        player.rotation = 0;
        player.direction = glm::vec3(0,0,-1);
    }
    if(cutscene_count > 0 && !reverse_cutscene) cutscene_count--;
    if(cutscene_count == duration-60) rock[3].position.x = 1000;
    if(cutscene_count == duration-120) rock[0].position.x = 1000;
    if(cutscene_count == duration-180) rock[1].position.x = 1000;
    if(cutscene_count == duration-240) rock[2].position.x = 1000;
    if(cutscene_count == duration-300) barrel[3].position.x = 1000;
    if(cutscene_count == duration-345) barrel[2].position.x = 1000;
    if(cutscene_count == duration-375) barrel[0].position.x = 1000;
    if(cutscene_count == duration-390) barrel[1].position.x = 1000;
    if(cutscene_count == 90 && !is_boss){ boss = Boss(0, 0, -100, 180, glm::vec3(0, 0, 1), glm::vec3(0,0,0), COLOR_BLACK, COLOR_BLACK, COLOR_BLACK, COLOR_RED); is_boss = true;}
    if(cutscene_count == 1 && !reverse_cutscene){
        cutscene_count = 120;
        reverse_cutscene = true;
    }
    if(cutscene_count <= 240 && reverse_cutscene) cutscene_count++;
    if(cutscene_count == 240 && reverse_cutscene){ reverse_cutscene = false; cutscene_count = 0;}
}
void tick_elements() {
    player.tick();
    cannon.tick();
    mortar_cannon.tick();
    boss_cannon.tick();
    enemy.tick();
    for(int i=0; i<5; i++)healthpickup[i].tick();
    boss.tick();

    //Mouse
    old_x = current_x, old_y = current_y;
    glfwGetCursorPos(window, &current_x, &current_y);
        if (current_x < old_x && cam_view == HELICOPTER_V) {
            camera_xz_angle-=2;
        }
        if (current_x > old_x && cam_view == HELICOPTER_V){
            camera_xz_angle+=2;
        }
        if (current_y > old_y && cam_view == HELICOPTER_V && camera_y_angle <= 80){
            camera_y_angle += 2;
        }
        if (current_y < old_y && cam_view == HELICOPTER_V && camera_y_angle >= 10){
            camera_y_angle -= 2;
        }
}

void initGL(GLFWwindow *window, int width, int height) {

    water        = Water(0, 0, 0, COLOR_WATER);
    player       = Ball(0, 0, 0, 0, glm::vec3(0, 0, -1), glm::vec3(0,0,0), COLOR_BOAT, COLOR_BOAT, COLOR_BOAT, COLOR_SAIL);
    rock[0]      = Rock(50, 0, 0, COLOR_BLACK);
    rock[1]      = Rock(0, 0, 50, COLOR_BLACK);
    rock[2]      = Rock(-50, 0, 0, COLOR_BLACK);
    rock[3]      = Rock(0, 0, -50, COLOR_BLACK);
    barrel[0]      = Barrel(25*1.4, 0, 25*1.4, COLOR_BARREL);
    barrel[1]      = Barrel(-25*1.4, 0, 25*1.4, COLOR_BARREL);
    barrel[2]      = Barrel(25*1.4, 0, -25*1.4, COLOR_BARREL);
    barrel[3]      = Barrel(-25*1.4, 0, -25*1.4, COLOR_BARREL);
    healthpickup[0]= HealthPickUp(25*1.4, 4, 25*1.4, COLOR_BOAT);
    healthpickup[1]= HealthPickUp(-25*1.4, 4, 25*1.4, COLOR_BOAT);
    healthpickup[2]= HealthPickUp(25*1.4, 4, -25*1.4, COLOR_BOAT);
    healthpickup[3]= HealthPickUp(-25*1.4, 4, -25*1.4, COLOR_BOAT);
    healthpickup[4]= HealthPickUp(1000, 4, 0, COLOR_BOAT);
    enemy     = Enemy(50*1.4, 0, -50*1.4, COLOR_ENEMY);
    mortar    = Mortar(-50*1.4, 0, -50*1.4, COLOR_GREY, COLOR_GREY, COLOR_GREY);
    boss = Boss(0, 0, 1000, 180, glm::vec3(0, 0, 1), glm::vec3(0,0,0), COLOR_BLACK, COLOR_BLACK, COLOR_BLACK, COLOR_RED);

    glfwGetCursorPos(window, &current_x, &current_y);
    old_x = current_x, old_y = current_y;

    // Create and compile our GLSL program from the shaders
    programID = LoadShaders("Sample_GL.vert", "Sample_GL.frag");
    // Get a handle for our "MVP" uniform
    Matrices.MatrixID = glGetUniformLocation(programID, "MVP");


    reshapeWindow (window, width, height);

    // Background color of the scene
    glClearColor (COLOR_BACKGROUND.r / 256.0, COLOR_BACKGROUND.g / 256.0, COLOR_BACKGROUND.b / 256.0, 0.0f); // R, G, B, A
    glClearDepth (1.0f);

    glEnable (GL_DEPTH_TEST);
    glDepthFunc (GL_LEQUAL);

    cout << "VENDOR: " << glGetString(GL_VENDOR) << endl;
    cout << "RENDERER: " << glGetString(GL_RENDERER) << endl;
    cout << "VERSION: " << glGetString(GL_VERSION) << endl;
    cout << "GLSL: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << endl;
}


int main(int argc, char **argv) {
    srand(time(0));
    int width  = 1920;
    int height = 1080;

    window = initGLFW(width, height);

    initGL (window, width, height);

    /* Draw in loop */
    while (!glfwWindowShouldClose(window)) {
        // Process timers

        if (t60.processTick()) {
            // 60 fps
            // OpenGL Draw commands
            draw();
            // Swap Frame Buffer in double buffering
            glfwSwapBuffers(window);

            tick_elements();
            tick_input(window);
        }

        // Poll for Keyboard and mouse events
        glfwPollEvents();
    }

    quit(window);
}

bool detect_collision(bounding_box_t a, bounding_box_t b) {
    return (abs(a.x - b.x) * 2 < (a.width + b.width)) &&
           (abs(a.y - b.y) * 2 < (a.height + b.height));
}

void reset_screen() {
    float top    = screen_center_y + 18 / screen_zoom;
    float bottom = screen_center_y - 18 / screen_zoom;
    float left   = screen_center_x - 32 / screen_zoom;
    float right  = screen_center_x + 32 / screen_zoom;
    if (project_char == 'o')Matrices.projection = glm::ortho(left, right, bottom, top, 0.01f, 1000.0f);
    else Matrices.projection = glm::perspective(120.0f, 16.0f/9, 0.01f, 500.0f);
}
