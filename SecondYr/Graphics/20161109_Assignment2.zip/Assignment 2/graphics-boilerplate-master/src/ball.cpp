#include "ball.h"
#include "main.h"

void Ball::insert_cube(GLfloat *vertex_buffer_data_pointer, int vertex_buffer_index, GLfloat *cube, float x, float y, float z)
{
    for(int i=0; i<108; i++)
    {
        if(i%3 == 0) vertex_buffer_data_pointer[vertex_buffer_index + i] = x+cube[i]; //x
        if(i%3 == 1) vertex_buffer_data_pointer[vertex_buffer_index + i] = y+cube[i]; //y
        if(i%3 == 2) vertex_buffer_data_pointer[vertex_buffer_index + i] = z+cube[i]; //z
    }
}

Ball::Ball(float x, float y, float z, float rotation, glm::vec3 direction, glm::vec3 speed, color_t color1, color_t color2, color_t color3, color_t color4) {
    this->position = glm::vec3(x, y, z);
    this->rotation = rotation; // Angle with -z axis
    this->direction = direction;
    this->speed = speed;
    this->acc = glm::vec3(0, -0.05, 0);
    GLfloat cube[] = {
        -1.0f,-1.0f,-1.0f, // triangle 1 : begin
        -1.0f,-1.0f, 1.0f,
        -1.0f, 1.0f, 1.0f, // triangle 1 : end
        1.0f, 1.0f,-1.0f, // triangle 2 : begin
        -1.0f,-1.0f,-1.0f,
        -1.0f, 1.0f,-1.0f, // triangle 2 : end
        1.0f,-1.0f, 1.0f,
        -1.0f,-1.0f,-1.0f,
        1.0f,-1.0f,-1.0f,
        1.0f, 1.0f,-1.0f,
        1.0f,-1.0f,-1.0f,
        -1.0f,-1.0f,-1.0f,
        -1.0f,-1.0f,-1.0f,
        -1.0f, 1.0f, 1.0f,
        -1.0f, 1.0f,-1.0f,
        1.0f,-1.0f, 1.0f,
        -1.0f,-1.0f, 1.0f,
        -1.0f,-1.0f,-1.0f,
        -1.0f, 1.0f, 1.0f,
        -1.0f,-1.0f, 1.0f,
        1.0f,-1.0f, 1.0f,
        1.0f, 1.0f, 1.0f,
        1.0f,-1.0f,-1.0f,
        1.0f, 1.0f,-1.0f,
        1.0f,-1.0f,-1.0f,
        1.0f, 1.0f, 1.0f,
        1.0f,-1.0f, 1.0f,
        1.0f, 1.0f, 1.0f,
        1.0f, 1.0f,-1.0f,
        -1.0f, 1.0f,-1.0f,
        1.0f, 1.0f, 1.0f,
        -1.0f, 1.0f,-1.0f,
        -1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f,
        -1.0f, 1.0f, 1.0f,
        1.0f,-1.0f, 1.0f
    };
    float height = 10.0f;
    GLfloat pole[] = {
        0.25f, 0, 0.25f,//base
        0.25f, 0, -0.25f,
        -0.25f, 0, 0.25f,

        -0.25f, 0, -0.25f,
        0.25f, 0, -0.25f,
        -0.25f, 0, 0.25f,

        0.25f, 0, 0.25f,//right
        0.25f, 0, -0.25f,
        0.25f, height, 0.25f,

        0.25f, height, 0.25f,
        0.25f, height, -0.25f,
        0.25f, 0, -0.25f,

        0.25f, 0, 0.25f,//up
        -0.25f, 0, 0.25f,
        0.25f, height, 0.25f,

        0.25f, height, 0.25f,
        -0.25f, height, 0.25f,
        -0.25f, 0, 0.25f,

        -0.25f, 0, 0.25f,//left
        -0.25f, 0, -0.25f,
        -0.25f, height, 0.25f,

        -0.25f, height, 0.25f,
        -0.25f, height, -0.25f,
        -0.25f, 0, -0.25f,

        -0.25f, 0, -0.25f,//down
        0.25f, 0, -0.25f,
        -0.25f, height, -0.25f,

        -0.25f, height, -0.25f,
        0.25f, height, -0.25f,
         0.25f, 0, -0.25f,

        0.25f, height, 0.25f,//top
        0.25f, height, -0.25f,
        -0.25f, height, 0.25f,

        /*0.25f, height, 0.25f,
        0.25f, height, -0.25f,
        -0.25f, height, 0.25f,*/

        //sail
        0.0f, height, 0.0f,
        0.0f, 1.0f, 0.0f,
        -5.0f, 1.0f, 0.0f
    };

    GLfloat vertex_buffer_data[11*108]; //11 cubes
    insert_cube(vertex_buffer_data, 108*0, cube, -2, 0, 2);
    insert_cube(vertex_buffer_data, 108*1, cube, -2, 0, 0);
    insert_cube(vertex_buffer_data, 108*2, cube, -2, 0, -2);
    insert_cube(vertex_buffer_data, 108*3, cube, 2, 0, 2);
    insert_cube(vertex_buffer_data, 108*4, cube, 2, 0, 0);
    insert_cube(vertex_buffer_data, 108*5, cube, 2, 0, -2);
    insert_cube(vertex_buffer_data, 108*6, cube, 0, 0, -4);
    insert_cube(vertex_buffer_data, 108*7, cube, 0, 0, 2);
    insert_cube(vertex_buffer_data, 108*8, cube, 0, 0, 0);
    insert_cube(vertex_buffer_data, 108*9, cube, 0, 0, -2);
    insert_cube(vertex_buffer_data, 108*10, pole, 0, 1, 0);

    this->vertex_buffer_data = vertex_buffer_data;

    this->object1 = create3DObject(GL_TRIANGLES, 12*3*3, vertex_buffer_data, color1, GL_FILL);
    this->object2 = create3DObject(GL_TRIANGLES, 12*3*3, &vertex_buffer_data[324], color2, GL_FILL);
    this->object3 = create3DObject(GL_TRIANGLES, 12*3*4, &vertex_buffer_data[648], color3, GL_FILL);
    this->object4 = create3DObject(GL_TRIANGLES, 12*3*1, &vertex_buffer_data[1080], color4, GL_FILL);}

void Ball::draw(glm::mat4 VP) {
    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    glm::mat4 rotate    = glm::rotate((float) (this->rotation * M_PI / 180.0f), glm::vec3(0, 1, 0));
    // No need as coords centered at 0, 0, 0 of cube arouund which we waant to rotate
    // rotate          = rotate * glm::translate(glm::vec3(0, -0.6, 0));
    Matrices.model *= (translate * rotate);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    //draw3DObject(this->object);
    draw3DObject(this->object1);
    draw3DObject(this->object2);
    draw3DObject(this->object3);
    draw3DObject(this->object4);
}

void Ball::set_position(float x, float y) {
    this->position = glm::vec3(x, y, 0);
}

void Ball::tick() {
//Directio vector relative to object rotation
    this->direction = glm::vec3(-sin(this->rotation * M_PI / 180.0f), 0, -cos(this->rotation * M_PI / 180.0f));
    this->speed.x -= 0.07*this->speed.x; //Friction
    this->speed.z -= 0.07*this->speed.z; //Friction

    this->speed += this->acc;
    this->position += this->speed;

    if(this->position.y < 0){ this->speed.y = 0; this->position.y = 0;}
}

bounding_box_t Ball::bounding_box() {
    float x = this->position.x, z = this->position.z;
    bounding_box_t bbox = { x, z, 6, 6 };
    return bbox;
}

