#include "main.h"

#ifndef BOSS_H
#define BOSS_H


class Boss {
public:
    Boss() {}
    Boss(float x, float y, float z, float rotation, glm::vec3 direction, glm::vec3 speed, color_t color1, color_t color2, color_t color3, color_t color4);
    glm::vec3 position, direction, direction2, direction3, speed, acc;
    float rotation;
    GLfloat *vertex_buffer_data;
    void draw(glm::mat4 VP);
    void set_color(color_t color1, color_t color2, color_t color3);
    void set_position(float x, float y);
    void tick();
    void insert_cube(GLfloat *vertex_buffer_data_pointer, int vertex_buffer_index, GLfloat *cube, float x, float y, float z);
    bounding_box_t bounding_box(), agro_box();
private:
    VAO *object1,*object2,*object3,*object4;
};

#endif // BOSS_H
