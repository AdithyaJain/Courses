#include "main.h"

const color_t COLOR_ENEMY = { 255-151, 255-45, 255-29 };
const color_t COLOR_SAIL = { 135, 211, 124 };
const color_t COLOR_BLACK = { 25, 25, 25 };
const color_t COLOR_BACKGROUND = {0, 110, 111};
const color_t COLOR_BOAT = { 151, 45, 29 };
const color_t COLOR_DMG_BOAT = {104, 33, 23};
const color_t COLOR_WATER = {9, 27, 99};
const color_t COLOR_BARREL = {124, 70, 16};
const color_t COLOR_GREY = {45, 45, 45};
const color_t COLOR_GREY2 = {30, 30, 30};
const color_t COLOR_GREY3 = {15, 15, 15};
const color_t COLOR_RED = {200, 35, 35};
