#include "main.h"

color_t COLOR_RED = { 255, 0, 0 };
color_t COLOR_BLUE = { 0, 0, 255 };
color_t COLOR_GREEN = { 0, 255, 0 };
color_t COLOR_GREY = { 75,75, 75 };
color_t COLOR_BACKGROUND = { 0, 0, 0 };
color_t COLOR_WHITE = {255, 255, 255};
