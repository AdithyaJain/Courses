#include "puddle.h"
#include "main.h"

Puddle::Puddle(float x, float y, color_t color) {
    this->position = glm::vec3(x, y, 0);
    this->rotation = 0;

    static GLfloat vertex_buffer_data[1000] = {0.0f};
        int n = 100;
        float angle = (2*M_PI)/n;

        for(int i=n/2; i<n; i++)
        {
            for(int j=1; j<3; j++)
            {
                    vertex_buffer_data[9*(i - n/2) + 3*j] = 6*cos((i+j-1)*angle);
                    vertex_buffer_data[9*(i - n/2) + 3*j + 1 ] = 6*sin((i+j-1)*angle);
                    vertex_buffer_data[9*(i - n/2) + 3*j + 2 ] = 0.0f;
            }
        }

    this->object = create3DObject(GL_TRIANGLES, 3*n, vertex_buffer_data, color, GL_FILL);
}

void Puddle::draw(glm::mat4 VP) {
    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    glm::mat4 rotate    = glm::rotate((float) (this->rotation * M_PI / 180.0f), glm::vec3(0, 0, 1));
    Matrices.model *= (translate * rotate);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->object);
}

void Puddle::set_position(float x, float y) {
    this->position = glm::vec3(x, y, 0);
}

void Puddle::tick() {
    // Do tick
}

bounding_box_t Puddle::bounding_box() {
    float x = this->position.x, y = this->position.y;
    bounding_box_t bbox = { x, y-3, 12, 6 };
    return bbox;
}
