#include "main.h"
#include "timer.h"
#include "ball.h"
#include "tramp.h"
#include "spike.h"
#include "puddle.h"
#include "magnet.h"
#include "floor.h"
#include "stdlib.h"

#define SCREEN 18
using namespace std;

GLMatrices Matrices;
GLuint     programID;
GLFWwindow *window;

/**************************
* Customizable functions *
**************************/
Ball player, enemy[21];
Tramp tramp;
Spike spike;
Puddle puddle;
Magnet magnet;
Floor floo;
int score = 0, green_count = 0, powerup = 0, powerup_ticks = 0;
char str_score[10];
float screen_zoom = 1, screen_center_x = 0, screen_center_y = 12;

Timer t60(1.0 / 60);

/* Render the scene with openGL */
/* Edit this function according to your assignment */
void draw() {
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // use the loaded shader program
    glUseProgram (programID);
    // Matrices.view = glm::lookAt( eye, target, up ); // Rotating Camera for 3D
    Matrices.view = glm::lookAt(glm::vec3(0, 0, 3), glm::vec3(0, 0, 0), glm::vec3(0, 1, 0)); // Fixed camera for 2D (ortho) in XY plane
    // Compute ViewProject matrix as view/camera might not be changed for this frame (basic scenario)
    glm::mat4 VP = Matrices.projection * Matrices.view;
    // Send our transformation to the currently bound shader, in the "MVP" uniform
    // For each model you render, since the MVP will be different (at least the M part)
    glm::mat4 MVP;  // MVP = Projection * View * Model

    // Scene render
    floo.draw(VP);
    magnet.draw(VP);
    for(int i=0; i<21; i++) enemy[i].draw(VP);
    tramp.draw(VP);
    spike.draw(VP);
    puddle.draw(VP);
    player.draw(VP);

}

void tick_input(GLFWwindow *window) {
    int left  = glfwGetKey(window, GLFW_KEY_A);
    int right = glfwGetKey(window, GLFW_KEY_D);
    int up = glfwGetKey(window, GLFW_KEY_SPACE);
    int pan_left  = glfwGetKey(window, GLFW_KEY_LEFT);
    int pan_right = glfwGetKey(window, GLFW_KEY_RIGHT);
    int pan_up = glfwGetKey(window, GLFW_KEY_UP);
    int pan_down = glfwGetKey(window, GLFW_KEY_DOWN);
    int zoom_in = glfwGetKey(window, GLFW_KEY_Z);
    int zoom_out = glfwGetKey(window, GLFW_KEY_X);
    if (left) {
        player.xspeed = -0.3;
    }
    else if (right) {
        player.xspeed = 0.3;
    }
    if (up && player.position.y <= 1)
    {
        player.yspeed = 0.35;
    }
    if (pan_up) screen_center_y += 1;
    if (pan_down) screen_center_y -= 1;
    if (pan_right) screen_center_x += 1;
    if (pan_left) screen_center_x -= 1;
    if (zoom_in) screen_zoom *= 1.2;
    if (zoom_out) screen_zoom /= 1.2;
}

void tick_elements() {
    reset_screen();
//Score
    sprintf(str_score, "Score: %d", score);
    glfwSetWindowTitle(window, str_score);
    player.tick();
    tramp.tick();
    spike.tick();
    magnet.tick();
    for(int i=0; i<20; i++) enemy[i].tick();
//Enemy Collision
    for(int i=0; i<20; i++)
    {
        if (detect_collision(player.bounding_box(), enemy[i].bounding_box())) {
            if(player.position.y > enemy[i].position.y && player.yspeed < 0){
                player.yspeed = 0.35;
                if(i < 10){ enemy[i].set_position(rand()%(SCREEN) - SCREEN*2, float((rand()%3 + 2)*2)); score += 10; green_count = 0;}
                else if(i < 17){ enemy[i].set_position(rand()%(SCREEN) - SCREEN*2, float((rand()%4 + 5)*2)); score += 20; green_count = 0;}
                else{ enemy[i].set_position(rand()%(SCREEN) - SCREEN*2, float((rand()%4 + 9)*2)); score += 30; green_count++;}
            }
        }
    }
    for(int i=0; i<10; i++) if(enemy[i].position.x > SCREEN+2) enemy[i].set_position(rand()%(SCREEN) - SCREEN*2, float((rand()%3 + 2)*2));
    for(int i=10; i<17; i++) if(enemy[i].position.x > SCREEN+2) enemy[i].set_position(rand()%(SCREEN) - SCREEN*2, float((rand()%4 + 5)*2));
    for(int i=17; i<21; i++) if(enemy[i].position.x > SCREEN+2) enemy[i].set_position(rand()%(SCREEN) - SCREEN*2, float((rand()%4 + 9)*2));
//Tramp Collision
    if (detect_collision(player.bounding_box(), tramp.bounding_box()) && player.position.y > tramp.position.y && player.yspeed < 0){
        player.yspeed = 0.8;
    }
//Spike Collision
    if (detect_collision(player.bounding_box(), spike.bounding_box())){
        quit(window);
    }
//Spike Movement
    if (spike.position.y == 0 && spike.xspeed == 0 ) spike.xspeed = 0.1;
    if (spike.position.x > 15 || spike.position.x < 0) spike.xspeed = -spike.xspeed;
//Water collision
    if (detect_collision(player.bounding_box(), puddle.bounding_box())){
        player.xspeed /= 1.2;
        player.yspeed /= 1.2;
    }
//Magnet collision
    if (detect_collision(player.bounding_box(), magnet.bounding_box())){
        player.xspeed += 0.05;
    }
//Magnet Movement
    if (magnet.position.y > 24 || magnet.position.y < 14) magnet.yspeed = -magnet.yspeed;
//Difficulty
    if (score >= 100) tramp.position.x += 0.5;
    if (score >= 200) spike.yacc = -0.05;
    if (score >= 300) magnet.xspeed = -0.3;
//5 green ball powerup
    if (green_count == 5) powerup = 1;
    if (powerup){
        glfwSetWindowTitle(window, "ZA WARUDO");
        for(int i=0; i<21; i++) enemy[i].xspeed = 0;
        powerup_ticks++;
        if(powerup_ticks > 360){
            powerup_ticks = 0;
            powerup = 0;
            green_count = 0;
            srand(time(NULL));
            for(int i=0; i<21; i++) enemy[i].xspeed = float(rand()%20 + 10)/100;
        }
    }
}

void initGL(GLFWwindow *window, int width, int height) {

//INITIALIZING PLAYER AND ENEMIES
    floo        = Floor(0, 0, COLOR_WHITE);
    player       = Ball(0, 1, 0, -0.012, COLOR_GREY);
    tramp        = Tramp(7, 2, COLOR_BLUE);
    spike        = Spike(14, 35, COLOR_RED);
    puddle       = Puddle(-10, 0, COLOR_BLUE);
    magnet       = Magnet(50, 19, COLOR_RED);
    srand(time(NULL));
    for(int i = 0; i<10; i++)
    {
        color_t r = { 255, rand()%128, 0 };
        enemy[i] = Ball(rand()%(SCREEN*2) - SCREEN*3, float((rand()%3 + 2)*2), float(rand()%20 + 10)/100, 0, r);
    }
    for(int i = 10; i<17; i++)
    {
        color_t b = { (rand()%20) * 5, (rand()%20)*5, 255 };
        enemy[i] = Ball(rand()%(SCREEN*2) - SCREEN*3, float((rand()%4 + 5)*2), float(rand()%20 + 10)/100, 0, b);
    }
    for(int i = 17; i<21; i++)
    {
        color_t g = { 0, (rand()%20)*5 + 150, 0 };
        enemy[i] = Ball(rand()%(SCREEN*2) - SCREEN*3, float((rand()%4 + 9)*2), float(rand()%20 + 10)/100, 0, g);
    }

    programID = LoadShaders("Sample_GL.vert", "Sample_GL.frag");
    Matrices.MatrixID = glGetUniformLocation(programID, "MVP");


    reshapeWindow (window, width, height);

    // Background color of the scene
    glClearColor (COLOR_BACKGROUND.r / 256.0, COLOR_BACKGROUND.g / 256.0, COLOR_BACKGROUND.b / 256.0, 0.0f); // R, G, B, A
    glClearDepth (1.0f);

    glEnable (GL_DEPTH_TEST);
    glDepthFunc (GL_LEQUAL);

    cout << "VENDOR: " << glGetString(GL_VENDOR) << endl;
    cout << "RENDERER: " << glGetString(GL_RENDERER) << endl;
    cout << "VERSION: " << glGetString(GL_VERSION) << endl;
    cout << "GLSL: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << endl;
}


int main(int argc, char **argv) {
    srand(time(0));
    int width  = 600;
    int height = 600;

    window = initGLFW(width, height);

    initGL (window, width, height);

    /* Draw in loop */
    while (!glfwWindowShouldClose(window)) {
        // Process timers

        if (t60.processTick()) {
            // 60 fps
            // OpenGL Draw commands
            draw();
            // Swap Frame Buffer in double buffering
            glfwSwapBuffers(window);

            tick_elements();
            tick_input(window);
        }

        // Poll for Keyboard and mouse events
        glfwPollEvents();
    }

    quit(window);
}

bool detect_collision(bounding_box_t a, bounding_box_t b) {
    return (abs(a.x - b.x) * 2 < (a.width + b.width)) &&
           (abs(a.y - b.y) * 2 < (a.height + b.height));
}

void reset_screen() {
    float top    = screen_center_y + SCREEN / screen_zoom;
    float bottom = screen_center_y - SCREEN/ screen_zoom;
    float left   = screen_center_x - SCREEN / screen_zoom;
    float right  = screen_center_x + SCREEN / screen_zoom;
    Matrices.projection = glm::ortho(left, right, bottom, top, 0.1f, 500.0f);
}
