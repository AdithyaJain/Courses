#include "main.h"

#ifndef SPIKE_H
#define SPIKE_H


class Spike {
public:
    Spike() {}
    Spike(float x, float y, color_t color);
    glm::vec3 position;
    float rotation;
    double xspeed, yspeed, yacc;
    void draw(glm::mat4 VP);
    void set_position(float x, float y);
    void tick();
    bounding_box_t bounding_box();
private:
    VAO *object;
};

#endif // TRAMP_H
#ifndef SPIKE_H
#define SPIKE_H


class spike
{
public:
    spike();
};

#endif // SPIKE_H
