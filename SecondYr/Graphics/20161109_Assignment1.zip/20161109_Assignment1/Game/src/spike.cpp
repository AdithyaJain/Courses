#include "spike.h"
#include "main.h"

Spike::Spike(float x, float y, color_t color) {
    this->position = glm::vec3(x, y, 0);
    this->rotation = 0;
    this->xspeed = 0;

    static GLfloat vertex_buffer_data[1000] = {
        0.0f, 2.0f, 0.0f,
        0.5f, 0.0f, 0.0f,
        -0.5f, 0.0f, 0.0f,

        2.0f, 2.0f, 0.0f,
        0.5f, 0.0f, 0.0f,
        1.5f, 0.0f, 0.0f,

        -2.0f, 2.0f, 0.0f,
        -0.5f, 0.0f, 0.0f,
        -1.5f, 0.0f, 0.0f,

    };
    this->object = create3DObject(GL_TRIANGLES, 3*3, vertex_buffer_data, color, GL_FILL);
}

void Spike::draw(glm::mat4 VP) {
    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    glm::mat4 rotate    = glm::rotate((float) (this->rotation * M_PI / 180.0f), glm::vec3(0, 0, 1));
    Matrices.model *= (translate * rotate);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->object);
}

void Spike::set_position(float x, float y) {
    this->position = glm::vec3(x, y, 0);
}

void Spike::tick() {
    this->position.x += xspeed;
    this->position.y += yspeed;
    this->yspeed += yacc;
    if (this->position.y < 0){
        this->position.y = 0;
        yspeed = 0;
        yacc = 0;
    }
}

bounding_box_t Spike::bounding_box() {
    float x = this->position.x, y = this->position.y;
    bounding_box_t bbox = { x, y + 1, 4, 1 };
    return bbox;
}
