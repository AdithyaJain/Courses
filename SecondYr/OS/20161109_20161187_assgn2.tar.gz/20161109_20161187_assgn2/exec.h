#ifndef EXEC
#define EXEC

int exec(int argNo, char **argv);

#endif