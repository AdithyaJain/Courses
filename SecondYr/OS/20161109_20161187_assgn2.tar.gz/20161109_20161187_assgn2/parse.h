#ifndef PARSE
#define PARSE

int parse(char *buffer, char **pBuffer);

#endif