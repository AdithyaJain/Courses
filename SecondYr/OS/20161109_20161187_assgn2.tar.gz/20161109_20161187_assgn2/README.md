

README:

Contents:
1.Setting up shell
2.Running shell
			________


1. Setting up shell:

	*Change path variable in exec.c file to the absolute location of the directory which contains the shell script.

	*Change home variable from "/home/adi" to "/home/<username>"

2.Running shell:

	*Run "run.sh" script.