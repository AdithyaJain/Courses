#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include "exec.h"


int exec(int argNo, char **argv)
{
	char path[100] = "/home/adi/Documents/SecondYr/OS/20161109_20161187_assgn2/";
	pid_t pid = fork();

	if(pid == 0)	//ie. child process
	{
//Making path for defined funcs
		char pwd[4] = "pwd";
		char cd[3] = "cd";
		char echo[5] = "echo";
		char ls[3] = "ls";
		char pinfo[6] = "pinfo";

		if(strcmp(argv[0], pwd) == 0) argv[0] = strcat(path, pwd);
		if(strcmp(argv[0], cd) == 0) argv[0] = strcat(path, cd);
		if(strcmp(argv[0], echo) == 0) argv[0] = strcat(path, echo);
		if(strcmp(argv[0], ls) == 0) argv[0] = strcat(path, ls);
		if(strcmp(argv[0], pinfo) == 0) argv[0] = strcat(path, pinfo);
		

		if(execvp(argv[0], argv) != -1)
		{
			return 0;
		}
		else
		{
			printf("Command not found\n");
			return -1;
		}

	}

	if(strcmp(argv[argNo-1], "&") != 0) wait(NULL);
}

//strncat(path, pwd, strlen(pwd));