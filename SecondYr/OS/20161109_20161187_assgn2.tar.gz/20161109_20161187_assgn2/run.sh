#!/bin/bash
make clean
make all
make shell
./shell
