1.c

Usage: ./a.out [input file location]

2.c

Usage: ./a.out [Link file name]

I realized at the end that the printf functions should be sys calls.
Instead of changing all the printfs in my code, I,m just writing one example here to show that i know how to do it...

# printf("Hello");
is same as
# write(1, "Hello", 5);
