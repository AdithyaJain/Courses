#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

#define BUFFER_SZ 100000

void main(int argc, char* argv[])
{
	int i,o;
	char buff[BUFFER_SZ], rev[BUFFER_SZ];

	if(argc != 2)	//argc needs two arguments
	{
		printf("\"./a.out [file]\" is expected");
		return;
	}

	struct stat s = {0};
	if(stat("./Assignment", &s) == -1) mkdir("./Assignment", 0700);		//if assignment folder doesnt exist, create it

	i = open(argv[1], O_RDONLY);
	o = open("Assignment/output.txt", O_WRONLY | O_CREAT | O_TRUNC, 0600);

	if(i == -1)
	{
		printf("File not read\n");
		close(i);
		close(o);
		return;
	}

	lseek(i, 0, SEEK_END);												//Goes one ahead of EOF

	int j,k;						
	while(lseek(i, -2, SEEK_CUR) >= BUFFER_SZ-1)									//Check whether big enough for buffer. Need to do -2 since one ahead of EOF
	{
		lseek(i, -(BUFFER_SZ-1), SEEK_CUR);									//Go behind by buffer size and start reading the buff_sz
		read(i, &buff, BUFFER_SZ);
		for(j=0; j<BUFFER_SZ; j++)
		{
			if(buff[j] >= 'A' && buff[j] <= 'Z') rev[BUFFER_SZ-1-j] = buff[j] + 'a' - 'A';
			else if(buff[j] >= 'a' && buff[j] <= 'z') rev[BUFFER_SZ-1-j] = buff[j] + 'A' - 'a';
			else rev[BUFFER_SZ-1-j] = buff[j];
		}

		write(o, &rev, BUFFER_SZ);										//Write buff_sz
		lseek(i, -(BUFFER_SZ-1), SEEK_CUR);									//Go to the second last buff_sz
	}
//This is similiar to the top but with a custom size which is basically (no of char in input)%100000
	int cursor = lseek(i, 0, SEEK_CUR);
	lseek(i, 0, SEEK_SET);
	read(i, &buff, cursor+1);
	for(j=0; j<=cursor; j++)
	{
		if(buff[j] >= 'A' && buff[j] <= 'Z') rev[cursor-j] = buff[j] + 'a' - 'A';
		else if(buff[j] >= 'a' && buff[j] <= 'z') rev[cursor-j] = buff[j] + 'A' - 'a';
		else rev[cursor-j] = buff[j];
	}
	write(o, &rev, cursor+1);
	close(i);
	close(o);
}
