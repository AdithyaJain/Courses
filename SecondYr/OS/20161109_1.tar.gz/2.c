#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

void main(int argc, char* argv[])
{
	if(argc != 2)
	{
		printf("\"./a.out [linkname]\" is expected");
		return;
	}

	symlink("Assignment/output.txt", argv[1]);

	struct stat s = {0};

	printf("Check whether symlink is created: ");
	if(lstat(argv[1], &s) == -1) printf("No\n");
	else printf("Yes\n");

	printf("Checking whether dir is created: ");
	if(stat("Assignment", &s) == -1) printf("No");
	else printf("Yes\n");

	printf("Checking whether file is created: ");
	if(stat("Assignment/output.txt", &s) == -1) printf("No");
	else printf("Yes\n");

	printf("Checking whether dir is created: ");
	if(stat("Assignment", &s) == -1) printf("No");
	else printf("Yes\n");

	printf("\n");

	printf("User has read perm on file: ");
	if(stat("Assignment/output.txt",&s) != -1)
	{
		if(s.st_mode & S_IRUSR) printf("Yes\n");
		else printf("No\n");
	}

	printf("User has write perm on file: ");
	if(stat("Assignment/output.txt",&s) != -1)
	{
		if(s.st_mode & S_IWUSR) printf("Yes\n");
		else printf("No\n");
	}
	printf("User has exec perm on file: ");
	if(stat("Assignment/output.txt",&s) != -1)
	{
		if(s.st_mode & S_IXUSR) printf("Yes\n");
		else printf("No\n");
	}
	printf("Group has read perm on file: ");
	if(stat("Assignment/output.txt",&s) != -1)
	{
		if(s.st_mode & S_IRGRP) printf("Yes\n");
		else printf("No\n");
	}
	printf("Group has write perm on file: ");
	if(stat("Assignment/output.txt",&s) != -1)
	{
		if(s.st_mode & S_IWGRP) printf("Yes\n");
		else printf("No\n");
	}
	printf("Group has exec perm on file: ");
	if(stat("Assignment/output.txt",&s) != -1)
	{
		if(s.st_mode & S_IXGRP) printf("Yes\n");
		else printf("No\n");
	}
	printf("Other has read perm on file: ");
	if(stat("Assignment/output.txt",&s) != -1)
	{
		if(s.st_mode & S_IROTH) printf("Yes\n");
		else printf("No\n");
	}
	printf("Other has write perm on file: ");
	if(stat("Assignment/output.txt",&s) != -1)
	{
		if(s.st_mode & S_IWOTH) printf("Yes\n");
		else printf("No\n");
	}
	printf("Other has exec perm on file: ");
	if(stat("Assignment/output.txt",&s) != -1)
	{
		if(s.st_mode & S_IXOTH) printf("Yes\n");
		else printf("No\n");
	}

	printf("User has read perm on directory: ");
	if(stat("Assignment",&s) != -1)
	{
		if(s.st_mode & S_IRUSR) printf("Yes\n");
		else printf("No\n");
	}

	printf("User has write perm on directory: ");
	if(stat("Assignment",&s) != -1)
	{
		if(s.st_mode & S_IWUSR) printf("Yes\n");
		else printf("No\n");
	}
	printf("User has exec perm on directory: ");
	if(stat("Assignment",&s) != -1)
	{
		if(s.st_mode & S_IXUSR) printf("Yes\n");
		else printf("No\n");
	}
	printf("Group has read perm on directory: ");
	if(stat("Assignment",&s) != -1)
	{
		if(s.st_mode & S_IRGRP) printf("Yes\n");
		else printf("No\n");
	}
	printf("Group has write perm on directory: ");
	if(stat("Assignment",&s) != -1)
	{
		if(s.st_mode & S_IWGRP) printf("Yes\n");
		else printf("No\n");
	}
	printf("Group has exec perm on directory: ");
	if(stat("Assignment",&s) != -1)
	{
		if(s.st_mode & S_IXGRP) printf("Yes\n");
		else printf("No\n");
	}
	printf("Other has read perm on directory: ");
	if(stat("Assignment",&s) != -1)
	{
		if(s.st_mode & S_IROTH) printf("Yes\n");
		else printf("No\n");
	}
	printf("Other has write perm on directory: ");
	if(stat("Assignment",&s) != -1)
	{
		if(s.st_mode & S_IWOTH) printf("Yes\n");
		else printf("No\n");
	}
	printf("Other has exec perm on directory: ");
	if(stat("Assignment",&s) != -1)
	{
		if(s.st_mode & S_IXOTH) printf("Yes\n");
		else printf("No\n");
	}
}
