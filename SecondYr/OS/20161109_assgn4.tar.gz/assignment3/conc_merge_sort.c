#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>
#include <unistd.h>
void selectionsort(long long int arr[], long long int n);
void merge(long long int a[], long long int l1, long long int h1, long long int h2);
void mergesort(long long int a[], long long int l, long long int h);
void swap(long long int *xp, long long int *yp);


void selectionsort(long long int arr[], long long int n)
{
    long long int i;
    long long int j;
    long long int min_idx;
    for (i = 0; i < n-1; i++)
    {
        min_idx = i;
        for (j = i+1; j < n; j++)
          if (arr[j] < arr[min_idx])
            min_idx = j;

        swap(&arr[min_idx], &arr[i]);
    }
}

void swap(long long int *xp, long long int *yp)
{
    long long int temp = *xp;
    *xp = *yp;
    *yp = temp;
}

void merge(long long int a[], long long int l1, long long int h1, long long int h2)
{
    long long int count=h2-l1+1;
    long long int sorted[count];
    long long int i=l1;
    long long int k=h1+1, m=0;
    long long int arr_count = l1;
    while (i<=h1 && k<=h2)
    {
        if (a[i]<a[k])
            sorted[m++]=a[i++];
        else if (a[k]<a[i])
            sorted[m++]=a[k++];
        else if (a[i]==a[k])
        {
            sorted[m++]=a[i++];
            sorted[m++]=a[k++];
        }
    }

    while (i<=h1)
        sorted[m++]=a[i++];

    while (k<=h2)
        sorted[m++]=a[k++];

    for (i=0; i<count; i++,l1++)
        a[l1] = sorted[i];
}

void mergesort(long long int a[], long long int l, long long int h)
{
    long long int i, len=(h-l+1);
    if (len<=5)
    {
        selectionsort(a+l, len);
        return;
    }
    pid_t left_pid,right_pid;
    left_pid = fork();
    if (left_pid<0)
    {
        perror("left child process forking error\n");
        _exit(-1);
    }
    else if (left_pid==0)
    {
        mergesort(a,l,l+len/2-1);
        _exit(0);
    }
    else
    {
        right_pid = fork();
        if (right_pid<0)
        {
            perror("right child process forking error\n");
            _exit(-1);
        }
        else if(right_pid==0)
        {
            mergesort(a,l+len/2,h);
            _exit(0);
        }
    }

    int status;
    waitpid(left_pid, &status, 0);
    waitpid(right_pid, &status, 0);
    merge(a, l, l+len/2-1, h);
}

void randomarr(long long int a[], long long int len)
{
    long long int i;
    for (i=0; i<len; i++)
        a[i] = rand();
    return;
}

int main()
{
    long long int length;
    long long int shmid,*shm_array;
    scanf("%lld",&length);
    size_t SHM_SIZE = sizeof(long long int)*length;
    if ((shmid = shmget(IPC_PRIVATE, SHM_SIZE, IPC_CREAT | 0666)) < 0)
    {
        perror("shmget");
        _exit(1);
    }
    if ((shm_array = shmat(shmid, NULL, 0)) == (long long int *) -1)
    {
        perror("shmat");
        _exit(1);
    }
    srand(time(NULL));
    randomarr(shm_array, length);
    long long i;
    for(i=0; i<length; i++) printf("%lld ",shm_array[i]);
    printf("\n");
    mergesort(shm_array, 0, length-1);
    for(i=0; i<length; i++) printf("%lld ",shm_array[i]);
    printf("\n");
    if (shmdt(shm_array) == -1)
    {
        perror("shmdt");
        _exit(1);
    }
    if (shmctl(shmid, IPC_RMID, NULL) == -1)
    {
        perror("shmctl");
        _exit(1);
    }
    return 0;
}
