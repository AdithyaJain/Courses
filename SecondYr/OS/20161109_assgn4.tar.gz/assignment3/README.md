enter size of array. it will be randomly generated
