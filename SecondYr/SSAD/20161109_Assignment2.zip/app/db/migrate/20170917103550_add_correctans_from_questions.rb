class AddCorrectansFromQuestions < ActiveRecord::Migration[5.1]
  def change
    add_column :questions, :correctans, :string
  end
end
