class RemoveSubgenreFromQuestions < ActiveRecord::Migration[5.1]
  def change
    remove_column :questions, :subgenre, :string
  end
end
