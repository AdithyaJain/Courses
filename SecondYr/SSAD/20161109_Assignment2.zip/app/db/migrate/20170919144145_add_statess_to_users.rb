class AddStatessToUsers < ActiveRecord::Migration[5.1]
  def change
    add_column :users, :stateindex1, :integer, default: 0
    add_column :users, :statescore1, :integer, default: 0

    add_column :users, :stateindex2, :integer, default: 0
    add_column :users, :statescore2, :integer, default: 0

    add_column :users, :stateindex3, :integer, default: 0
    add_column :users, :statescore3, :integer, default: 0

    add_column :users, :stateindex4, :integer, default: 0
    add_column :users, :statescore4, :integer, default: 0
  end
end
