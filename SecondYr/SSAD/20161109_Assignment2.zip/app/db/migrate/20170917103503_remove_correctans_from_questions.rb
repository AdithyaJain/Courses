class RemoveCorrectansFromQuestions < ActiveRecord::Migration[5.1]
  def change
    remove_column :questions, :correctans, :integer
  end
end
