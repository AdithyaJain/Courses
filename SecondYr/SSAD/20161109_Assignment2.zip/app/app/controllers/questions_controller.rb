class QuestionsController < ApplicationController
  before_action :logged_in_user, only: [:index, :new, :create, :edit, :update, :destroy]
  before_action :correct_user,   only: [:new, :create, :edit, :update, :destroy]

  def show
    user = User.find(session[:user_id])
    questions = Question.where({genre: params[:genre]})
    @max = questions.length - 1
    @id = params[:id].to_i
    @score = params[:score].to_i
    @question = questions[@id]
    question = @question
    if @max < 0
      flash[:danger] = "No questions in quiz"
      redirect_to user_path(session[:user_id])
=begin    elsif
      if question.genre == "Sports Cricket"
        if user.stateindex1 > @id
          flash[:danger] = "Cant go back!!!"
          redirect_to question_path(:genre => 'Sports Cricket', :id => user.stateindex1, :score => user.statescore1)
        end
      elsif question.genre == "Sports Football"
        if user.stateindex2 > @id
          flash[:danger] = "Cant go back!!!"
          redirect_to question_path(:genre => 'Sports Football', :id => user.stateindex2, :score => user.statescore2)
        end
      elsif question.genre == "Movies Bollywood"
        if user.stateindex3 > @id
          flash[:danger] = "Cant go back!!!"
          redirect_to question_path(:genre => 'Movies Bollywood', :id => user.stateindex3, :score => user.statescore3)
        end
      elsif question.genre == "Movies Hollywood"
        if user.stateindex4 > @id
          flash[:danger] = "Cant go back!!!"
          redirect_to question_path(:genre => 'Movies Hollywood', :id => user.stateindex4, :score => user.statescore4)
        end
      end
=end
    else
      if question.genre == "Sports Cricket"
        user.update_attribute(:statescore1, @score)
        user.update_attribute(:stateindex1, @id)
      elsif question.genre == "Sports Football"
        user.update_attribute(:statescore2, @score)
        user.update_attribute(:stateindex2, @id)
      elsif question.genre == "Movies Bollywood"
        user.update_attribute(:statescore3, @score)
        user.update_attribute(:stateindex3, @id)
      elsif question.genre == "Movies Hollywood"
        user.update_attribute(:statescore4, @score)
        user.update_attribute(:stateindex4, @id)
      end
    end
  end

  def ans
    user = User.find(session[:user_id])
    genre = params[:question][:genre]
    id = params[:question][:id].to_i
    score = params[:question][:score].to_i

    questions = Question.where({genre: genre})
    question = questions[id]
    @max = questions.length - 1

    userans = params[:question][:option1]+params[:question][:option2]+params[:question][:option3]+params[:question][:option4]
    if question.correctans == userans
      score += 1
    end

    if @max > id
      redirect_to question_path(:genre => genre, :id => id+1, :score => score)
    else
      if question.genre == "Sports Cricket"
        if user.score1 < score
          user.update_attribute(:score1, score)
        end
        user.update_attribute(:statescore1, 0)
        user.update_attribute(:stateindex1, 0)
      elsif question.genre == "Sports Football"
        if user.score2 < score
          user.update_attribute(:score2, score)
        end
        user.update_attribute(:statescore2, 0)
        user.update_attribute(:stateindex2, 0)
      elsif question.genre == "Movies Bollywood"
        if user.score3 < score
          user.update_attribute(:score3, score)
        end
        user.update_attribute(:statescore3, 0)
        user.update_attribute(:stateindex3, 0)
      elsif question.genre == "Movies Hollywood"
        if user.score4 < score
          user.update_attribute(:score4, score)
        end
        user.update_attribute(:statescore4, 0)
        user.update_attribute(:stateindex4, 0)
      end
      redirect_to users_path
    end
  end

  def index
    if params[:genre] == nil
      @question = Question.all
    else
      @question = Question.where({genre: params[:genre]})
    end
  end

  def new
    @question = Question.new
  end

  def create
    @question = Question.new(question_params)
    if @question.save
      flash[:success] = "Created new question"
      redirect_to questions_url
    else
      render 'new'
    end
  end

  def edit
    @question = Question.find(params[:id])
  end

  def update
    @question = Question.find(params[:id])
    if @question.update_attributes(question_params)
      flash[:success] = "Question updated"
      redirect_to questions_url
    else
      render 'edit'
    end
  end

  def destroy
    Question.find(params[:id]).destroy
    flash[:success] = "Question deleted"
    redirect_to questions_url
  end

  private

    def question_params
      params.require(:question).permit(:question,:option1,:option2,:option3,:option4,:genre,:correctans)
    end

    def logged_in_user
      unless logged_in?
        flash[:danger] = "Dont mess with URL or I'll mess with you!"
        redirect_to login_url
      end
    end

    def correct_user
      unless User.find(session[:user_id]).admin
        flash[:danger] = "Dont mess with URL or I'll mess with you!"
        @user = User.find(session[:user_id])
        redirect_to @user
      end
    end

end
