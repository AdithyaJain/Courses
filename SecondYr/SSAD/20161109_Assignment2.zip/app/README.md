# README


Admin login
email: mg@g.c
password: 1234
