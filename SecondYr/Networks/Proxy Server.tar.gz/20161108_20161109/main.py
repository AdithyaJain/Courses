import socket
import datetime
import time
import os

def save_file(filename):
    pass


ports = 12345
portc = 20000
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR, 1)



host = ""

s.bind((host, ports))
s.listen(5)



print('Server listening....')

while True:
    c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    c.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR, 1)

    try:
        c.connect((host, portc))
    except Exception as e:
        print("Server error")
        time.sleep(5)


    conn, addr = s.accept()
    #print('Got connection from', addr)
    data = conn.recv(1024)
    #print(data)
    #print('Server received', repr(data))


    #data = data[0:4] + data[-10:]
    
    data = data.decode('utf-8')
    if "http://localhost:" not in data:
        continue

    filename = data.split("http://localhost:" + str(portc) + "/", 1)[1].split(" ", 1)[0]
    #print("Filename is " + filename)


    data = data.replace("http://localhost:" + str(portc), "")
    print('\n' + data + '\n')
    data = bytearray(data, 'utf-8')


    cache = []
    try:
        with open("cache.txt", "r") as cache_file:
            cache = [w.strip() for w in cache_file.readlines()]
            print(cache)
    except:
        print("Cache doesn't exist")

    if filename in cache:
        print("Cache hit: " + filename)

        # Generate timestamp
        #curr_time = os.path.getmtime(filename)
        #timestamp = time.strftime("If-Modified-Since: %a, %d %b %Y %H:%M:%S GMT", time.gmtime(curr_time))
        timestamp = 'If-Modified-Since: ' + time.strftime("%a %b %d %H:%M:%S %Y", time.strptime(time.ctime(os.path.getmtime(filename)), "%a %b %d %H:%M:%S %Y")) + '\r\n\r\n'
        print(timestamp)

        # Send If-Modified-Since to server

        data = data.decode('utf-8')
        data = data.replace("\r\n\r\n", "\r\n" + timestamp + "\r\n\r\n")
        data = data.replace("max-age=0", "max-age=864000")
        print(data + "\n" * 3)
        data = bytes(data, 'utf-8')
        print(data.decode('utf-8'))
        
        try:
            c.send(data)
            data = b''
            while True:
                packet = c.recv(1024)
                if not packet:
                    break
                data += packet
            c.close()

            print(data.decode('utf-8'))

            data = data.decode('utf-8')
            if "HTTP/1.0 304 Not Modified" not in data:
                with open(filename, "wb") as f:
                    f.write(bytes(data, 'utf-8'))
                
        except Exception as e:
            print("Cache coherency check failed!")
            print(e)

        try:
            with open(filename, "r") as f:
                data = bytearray(f.read(), 'utf-8')
        except Exception as e:
            print(e)
            print("ERROR: " + filename + " doesn't exist")
            cache.remove(filename)
    else:
        #c.send(bytearray(data, 'utf-8'))
        try:
            c.send(data)
        except:
            print("Server error")
            time.sleep(5)

        #data = str(c.recv(1024))
        data = b''
        while True:
            packet = c.recv(1024)
            if not packet:
                break
            data += packet
        c.close()

        if filename != '':
            if len(cache) < 3:
                cache.append(filename)
            else:
                cache.append(filename)
                popped_file = cache[0]
                cache.remove(popped_file)
                try:
                    os.remove(popped_file)
                except:
                    print("ERROR: " + popped_file + " doesn't exist")

            with open(filename, "wb") as f:
                f.write(data)

        
    conn.send(data)
    conn.close()
    
    with open("cache.txt", "w") as cache_file:
        cache_file.write("\n".join(cache))


    #conn.send(bytearray(data, 'utf-8'))


